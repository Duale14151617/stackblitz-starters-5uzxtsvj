/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        duale: {
          900: "#0d3b28",
          700: "#12603f",
          600: "#1a7a4c",
          500: "#22a35e",
          100: "#e7f5ec",
        },
        cream: "#f7f8f5",
        ink: "#101815",
      },
    },
  },
  plugins: [],
};
