import React from "react";
import { Phone, LogOut } from "lucide-react";
import Logo from "./Logo";
import { Button, Badge } from "./ui";
import { useAuth } from "../context/AuthContext";

const roleLabel = { customer: "Customer", agent: "Agent", manager: "Manager" };

export default function PublicNav({ onNav, onOpenAuth }) {
  const { user, signOut } = useAuth();
  return (
    <header className="bg-white border-b border-[var(--line)] sticky top-0 z-40">
      <nav className="max-w-[1280px] mx-auto px-6 h-[72px] flex items-center justify-between">
        <button className="focus-ring rounded-lg" onClick={() => onNav("home")}>
          <Logo variant="full" theme="light" size={38} />
        </button>
        <div className="hidden md:flex items-center gap-7 text-[15px] font-medium">
          <button onClick={() => onNav("home")} className="chip-active focus-ring rounded">Home</button>
          <button onClick={() => onNav("book")} className="hover:text-[var(--green-600)] focus-ring rounded">Book Ticket</button>
        </div>
        <div className="flex items-center gap-3">
          <span className="hidden lg:flex items-center gap-1.5 text-sm font-semibold text-[var(--ink)]"><Phone size={14} />+252 61 1234567</span>
          {user ? (
            <div className="flex items-center gap-2">
              <Badge tone="success">{roleLabel[user.role]}</Badge>
              <Button size="sm" variant="ghost" onClick={() => onNav("dashboard")}>Dashboard</Button>
              <Button size="sm" variant="outline" onClick={signOut}><LogOut size={14} />Log out</Button>
            </div>
          ) : <Button size="sm" onClick={onOpenAuth}>Sign in</Button>}
        </div>
      </nav>
    </header>
  );
}
