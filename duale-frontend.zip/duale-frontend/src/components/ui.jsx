import React from "react";
import { X, Edit2, Trash2, Loader2, FileText } from "lucide-react";
import { cls } from "../lib/helpers";

export function Button({ variant = "primary", size = "md", className = "", children, loading, ...props }) {
  const sizes = { sm: "px-3 py-1.5 text-sm", md: "px-5 py-2.5 text-[15px]", lg: "px-6 py-3.5 text-[15px]" };
  const base = "rounded-lg font-semibold inline-flex items-center justify-center gap-2 focus-ring disabled:opacity-50 disabled:cursor-not-allowed";
  const variants = { primary: "btn-primary", outline: "btn-outline bg-transparent", ghost: "text-[var(--gray-600)] hover:bg-black/5", danger: "bg-red-600 text-white hover:bg-red-700" };
  return (
    <button className={cls(base, sizes[size], variants[variant], className)} disabled={loading || props.disabled} {...props}>
      {loading && <Loader2 size={14} className="spin" />}
      {children}
    </button>
  );
}

export function Card({ className = "", children, hover = false }) {
  return <div className={cls("bg-white border border-[var(--line)] rounded-2xl", hover && "card-hover", className)}>{children}</div>;
}

export function Badge({ tone = "neutral", children }) {
  const tones = { neutral: "bg-gray-100 text-gray-600", success: "bg-[var(--green-100)] text-[var(--green-700)]", warn: "bg-amber-50 text-amber-700", danger: "bg-red-50 text-red-600" };
  return <span className={cls("inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold", tones[tone])}>{children}</span>;
}

export function Field({ label, children, hint }) {
  return (
    <label className="block">
      <span className="block text-xs font-semibold uppercase tracking-wide text-[var(--gray-400)] mb-1.5">{label}</span>
      {children}
      {hint && <span className="block text-xs text-[var(--gray-400)] mt-1">{hint}</span>}
    </label>
  );
}

export function Input(props) {
  return <input {...props} className={cls("w-full border border-[var(--line)] rounded-lg px-3.5 py-2.5 text-[15px] focus-ring outline-none", props.className)} />;
}

export function Select({ children, ...props }) {
  return <select {...props} className={cls("w-full border border-[var(--line)] rounded-lg px-3.5 py-2.5 text-[15px] bg-white focus-ring outline-none", props.className)}>{children}</select>;
}

export function Modal({ open, onClose, title, children, width = "max-w-lg" }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 fade-in" role="dialog" aria-modal="true" aria-label={title}>
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className={cls("relative bg-white rounded-2xl w-full slide-up max-h-[88vh] overflow-y-auto", width)}>
        <div className="flex items-center justify-between px-6 py-4 border-b border-[var(--line)] sticky top-0 bg-white rounded-t-2xl">
          <h3 className="font-bold text-lg">{title}</h3>
          <button onClick={onClose} aria-label="Close" className="p-1.5 rounded-lg hover:bg-gray-100 focus-ring"><X size={18} /></button>
        </div>
        <div className="p-6">{children}</div>
      </div>
    </div>
  );
}

export function Tabs({ tabs, active, onChange }) {
  return (
    <div className="flex gap-1 overflow-x-auto pb-1" role="tablist">
      {tabs.map((t) => (
        <button key={t.key} role="tab" aria-selected={active === t.key} onClick={() => onChange(t.key)}
          className={cls("flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold whitespace-nowrap focus-ring transition-colors", active === t.key ? "bg-[var(--green-700)] text-white" : "text-[var(--gray-600)] hover:bg-[var(--green-100)]")}>
          {t.icon && <t.icon size={15} />}{t.label}
        </button>
      ))}
    </div>
  );
}

export function StatCard({ icon: Icon, label, value, sub }) {
  return (
    <Card className="p-5 flex items-center gap-4" hover>
      <div className="w-11 h-11 rounded-xl bg-[var(--green-100)] text-[var(--green-700)] flex items-center justify-center shrink-0"><Icon size={20} /></div>
      <div>
        <div className="text-xl font-extrabold leading-tight">{value}</div>
        <div className="text-[13px] text-[var(--gray-600)]">{label}</div>
        {sub && <div className="text-[11px] text-[var(--gray-400)] mt-0.5">{sub}</div>}
      </div>
    </Card>
  );
}

export function EmptyState({ icon: Icon = FileText, title, sub }) {
  return (
    <div className="text-center py-16 text-[var(--gray-400)]">
      <Icon size={34} className="mx-auto mb-3 opacity-60" />
      <div className="font-semibold text-[var(--gray-600)]">{title}</div>
      {sub && <div className="text-sm mt-1">{sub}</div>}
    </div>
  );
}

export function DataTable({ columns, rows, onEdit, onDelete }) {
  if (!rows.length) return <EmptyState title="Nothing here yet" />;
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="text-left text-xs font-bold uppercase tracking-wide text-[var(--gray-400)] border-b border-[var(--line)]">
            {columns.map((c) => <th key={c.key} className="py-2.5 pr-4">{c.label}</th>)}
            {(onEdit || onDelete) && <th className="py-2.5" />}
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.id} className="border-b border-[var(--line)] last:border-0 hover:bg-[var(--cream)]">
              {columns.map((c) => <td key={c.key} className="py-3 pr-4">{c.render ? c.render(r) : r[c.key]}</td>)}
              {(onEdit || onDelete) && (
                <td className="py-3 flex gap-2 justify-end">
                  {onEdit && <button onClick={() => onEdit(r)} className="p-1.5 rounded hover:bg-gray-100 text-[var(--gray-600)] focus-ring"><Edit2 size={14} /></button>}
                  {onDelete && <button onClick={() => onDelete(r)} className="p-1.5 rounded hover:bg-red-50 text-red-500 focus-ring"><Trash2 size={14} /></button>}
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
