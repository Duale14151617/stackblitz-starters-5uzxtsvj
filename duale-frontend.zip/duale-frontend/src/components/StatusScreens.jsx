import React from "react";
import { AlertCircle, Loader2 } from "lucide-react";
import Logo from "./Logo";

export function LoadingScreen() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center gap-4 bg-[var(--cream)]">
      <Logo variant="full" theme="light" size={44} tagline />
      <Loader2 className="spin text-[var(--green-600)]" size={22} />
    </div>
  );
}

export function NotConfiguredScreen() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[var(--cream)] p-6">
      <div className="bg-white border border-[var(--line)] rounded-2xl p-8 max-w-md w-full">
        <Logo variant="full" theme="light" size={40} className="mb-6" />
        <div className="flex items-center gap-2 text-amber-600 mb-2"><AlertCircle size={18} /><h2 className="font-bold text-lg">API isn&apos;t configured</h2></div>
        <p className="text-sm text-[var(--gray-600)] leading-relaxed mb-4">
          This app needs to know where the PHP backend is running. Copy{" "}
          <code className="bg-[var(--cream)] px-1.5 py-0.5 rounded">frontend/.env.example</code> to{" "}
          <code className="bg-[var(--cream)] px-1.5 py-0.5 rounded">frontend/.env</code>, set{" "}
          <code className="bg-[var(--cream)] px-1.5 py-0.5 rounded">VITE_API_BASE_URL</code> to your backend&apos;s URL
          (e.g. <code className="bg-[var(--cream)] px-1.5 py-0.5 rounded">http://localhost:8000/api</code>), then restart the dev server.
        </p>
        <p className="text-xs text-[var(--gray-400)]">See README.md for the full setup steps.</p>
      </div>
    </div>
  );
}
