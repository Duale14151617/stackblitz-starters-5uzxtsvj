import React, { useState } from "react";
import { AlertCircle, CheckCircle2, Eye, EyeOff } from "lucide-react";
import { Modal, Field, Input, Button } from "./ui";
import { useAuth } from "../context/AuthContext";

export default function AuthModal({ open, onClose }) {
  const { signIn, signUp } = useAuth();
  const [mode, setMode] = useState("login");
  const [form, setForm] = useState({ name: "", email: "", password: "", phone: "" });
  const [showPw, setShowPw] = useState(false);
  const [err, setErr] = useState("");
  const [info, setInfo] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setErr(""); setInfo(""); setBusy(true);
    try {
      if (mode === "login") {
        await signIn(form.email, form.password);
        onClose();
      } else {
        const res = await signUp(form.name, form.email, form.password, form.phone);
        if (res.needsConfirmation) setInfo("Account created — check your email to confirm, then sign in.");
        else onClose();
      }
    } catch (e) {
      setErr(e.message || "Something went wrong.");
    }
    setBusy(false);
  };

  return (
    <Modal open={open} onClose={onClose} title={mode === "login" ? "Sign in to Du'ale" : "Create your account"}>
      <form onSubmit={submit} className="space-y-4">
        {mode === "signup" && <Field label="Full name"><Input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>}
        <Field label="Email"><Input type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></Field>
        {mode === "signup" && <Field label="Phone"><Input required value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="+252 6..." /></Field>}
        <Field label="Password">
          <div className="relative">
            <Input type={showPw ? "text" : "password"} required minLength={6} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
            <button type="button" onClick={() => setShowPw((s) => !s)} className="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--gray-400)]">{showPw ? <EyeOff size={16} /> : <Eye size={16} />}</button>
          </div>
        </Field>
        {err && <p className="text-sm text-red-600 flex items-center gap-1.5"><AlertCircle size={14} />{err}</p>}
        {info && <p className="text-sm text-[var(--green-700)] flex items-center gap-1.5"><CheckCircle2 size={14} />{info}</p>}
        <Button type="submit" className="w-full" size="lg" loading={busy}>{mode === "login" ? "Sign in" : "Create account"}</Button>
      </form>
      <p className="text-sm text-center text-[var(--gray-600)] mt-4">
        {mode === "login" ? "New to Du'ale?" : "Already have an account?"}{" "}
        <button onClick={() => setMode(mode === "login" ? "signup" : "login")} className="text-[var(--green-700)] font-semibold focus-ring">{mode === "login" ? "Create one" : "Sign in"}</button>
      </p>
    </Modal>
  );
}
