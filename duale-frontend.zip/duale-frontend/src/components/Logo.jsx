import React from "react";

/**
 * Du'ale brand mark — a flat, scalable recreation of the supplied logo
 * (arc swoosh + bus silhouette), built as SVG so it stays crisp at any size
 * and can swap its palette for light or dark surfaces without needing two
 * separate raster exports.
 *
 * Usage:
 *   <Logo />                              full lockup, light-surface colors
 *   <Logo theme="dark" />                 full lockup, for dark-green surfaces (sidebar, footer)
 *   <Logo variant="mark" size={40} />     icon only (navbar-compact, loading screens)
 *   <Logo variant="full" tagline />       icon + wordmark + tagline
 */
export default function Logo({ variant = "full", theme = "light", size = 40, tagline = false, className = "" }) {
  const isDark = theme === "dark";
  const iconFill = isDark ? "none" : "#12603f";
  const iconStroke = isDark ? "#ffffff" : "none";
  const windowFill = isDark ? "rgba(255,255,255,0.85)" : "#e7f5ec";
  const arcColor = isDark ? "#5bd68a" : "#1a7a4c";
  const wheelFill = isDark ? "#ffffff" : "#101815";
  const hubFill = isDark ? "#0d3b28" : "#22a35e";
  const textColor = isDark ? "#ffffff" : "#0d3b28";
  const taglineColor = isDark ? "#7fe3ac" : "#1a7a4c";

  const Icon = (
    <svg width={size} height={size} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <circle
        cx="50" cy="50" r="42"
        stroke={arcColor} strokeWidth="6" strokeLinecap="round"
        strokeDasharray="150 400" transform="rotate(-135 50 50)"
      />
      <g stroke={iconStroke} strokeWidth={isDark ? 2.5 : 0}>
        <rect x="18" y="40" width="64" height="30" rx="12" fill={iconFill} stroke={iconStroke} />
        <rect x="24" y="47" width="17" height="15" rx="4" fill={windowFill} />
        <rect x="45" y="47" width="30" height="11" rx="3" fill={windowFill} />
        <circle cx="33" cy="73" r="7.5" fill={wheelFill} />
        <circle cx="33" cy="73" r="3" fill={hubFill} />
        <circle cx="67" cy="73" r="7.5" fill={wheelFill} />
        <circle cx="67" cy="73" r="3" fill={hubFill} />
        <circle cx="22.5" cy="58" r="2.6" fill={arcColor} stroke="none" />
      </g>
    </svg>
  );

  if (variant === "mark") return <span className={className}>{Icon}</span>;

  return (
    <span className={`inline-flex items-center gap-2.5 ${className}`}>
      {Icon}
      <span className="leading-tight">
        <span className="block font-extrabold tracking-tight" style={{ color: textColor, fontSize: size * 0.42 }}>
          Du&apos;ale
        </span>
        {tagline && (
          <span className="block font-semibold uppercase" style={{ color: taglineColor, fontSize: size * 0.16, letterSpacing: "0.06em" }}>
            Travel Together, Safely
          </span>
        )}
      </span>
    </span>
  );
}
