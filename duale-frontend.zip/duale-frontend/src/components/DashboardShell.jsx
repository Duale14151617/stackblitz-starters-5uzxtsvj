import React, { useState } from "react";
import { LogOut, Menu, User, Ticket, LayoutDashboard } from "lucide-react";
import Logo from "./Logo";
import { cls } from "../lib/helpers";
import { useAuth } from "../context/AuthContext";

const roleTheme = {
  customer: { label: "Customer", icon: User },
  agent: { label: "Agent", icon: Ticket },
  manager: { label: "Manager", icon: LayoutDashboard },
};

export default function DashboardShell({ tabs, active, onChange, title, children }) {
  const { user, signOut } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);
  const RoleIcon = roleTheme[user.role].icon;

  return (
    <div className="min-h-screen flex bg-[var(--cream)]">
      <aside className={cls("bg-[var(--green-900)] text-white w-64 shrink-0 flex-col fixed lg:sticky top-0 h-screen z-40 transition-transform", mobileOpen ? "flex translate-x-0" : "hidden lg:flex")}>
        <div className="px-6 h-[72px] flex items-center border-b border-white/10"><Logo variant="mark" theme="dark" size={34} className="mr-2" /><span className="font-extrabold text-lg">Du&apos;ale</span></div>
        <div className="px-6 py-5 border-b border-white/10 flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center"><RoleIcon size={16} /></div>
          <div>
            <div className="text-sm font-bold leading-tight">{user.name}</div>
            <div className="text-xs text-white/50">{roleTheme[user.role].label}</div>
          </div>
        </div>
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {tabs.map((t) => (
            <button key={t.key} onClick={() => { onChange(t.key); setMobileOpen(false); }}
              className={cls("w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm font-semibold focus-ring transition-colors", active === t.key ? "bg-white/12 text-white" : "text-white/60 hover:bg-white/8 hover:text-white")}>
              <t.icon size={16} />{t.label}
            </button>
          ))}
        </nav>
        <div className="p-3 border-t border-white/10">
          <button onClick={signOut} className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm font-semibold text-white/60 hover:bg-white/8 hover:text-white focus-ring">
            <LogOut size={16} />Log out
          </button>
        </div>
      </aside>
      <div className="flex-1 min-w-0">
        <div className="lg:hidden flex items-center justify-between bg-white border-b border-[var(--line)] px-4 h-14 sticky top-0 z-30">
          <button onClick={() => setMobileOpen((s) => !s)} className="p-2 focus-ring"><Menu size={20} /></button>
          <div className="font-bold">{title}</div><div className="w-8" />
        </div>
        <main className="p-5 md:p-8 max-w-[1200px] mx-auto fade-in">
          <h1 className="text-2xl font-extrabold mb-1 hidden lg:block">{title}</h1>
          <p className="text-[var(--gray-600)] text-sm mb-6 hidden lg:block">Welcome back, {user.name.split(" ")[0]}.</p>
          {children}
        </main>
      </div>
    </div>
  );
}
