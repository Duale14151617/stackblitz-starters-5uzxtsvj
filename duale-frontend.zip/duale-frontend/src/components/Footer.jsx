import React from "react";
import Logo from "./Logo";

export default function Footer() {
  return (
    <footer style={{ background: "var(--green-900)" }} className="text-[#cfe3d6] py-12">
      <div className="max-w-[1280px] mx-auto px-6">
        <Logo variant="full" theme="dark" size={38} />
        <p className="max-w-sm text-[13.5px] leading-relaxed mt-4 text-[#a9c4b3]">
          Travel together, safely. Booking bus tickets across Somalia made simple, fast and reliable.
        </p>
        <div className="border-t border-white/10 mt-8 pt-5 text-center text-[12.5px] text-[#8fae9b]">
          © {new Date().getFullYear()} Du&apos;ale. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
