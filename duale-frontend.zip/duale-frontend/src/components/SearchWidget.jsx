import React, { useMemo, useState } from "react";
import { MapPin, Calendar, User, ArrowRightLeft, Search } from "lucide-react";
import { Field, Select, Input, Button } from "./ui";
import { addDays } from "../lib/helpers";
import { useApi } from "../context/DataContext";

export default function SearchWidget({ onSearch }) {
  const { api } = useApi();
  const routes = api.getRoutes();
  const cities = useMemo(() => [...new Set(routes.flatMap((r) => [r.from, r.to]))], [routes]);
  const [from, setFrom] = useState(cities[0] || "Mogadishu");
  const [to, setTo] = useState(cities[1] || "Hargeisa");
  const [date, setDate] = useState(addDays(new Date(), 1).toISOString().slice(0, 10));
  const [passengers, setPassengers] = useState(1);
  const swap = () => { setFrom(to); setTo(from); };

  return (
    <div className="bg-white rounded-2xl shadow-[0_24px_60px_rgba(0,0,0,0.18)] p-5 md:p-6">
      <div className="flex gap-7 border-b border-[var(--line)] pb-3.5 mb-5 text-sm font-semibold text-[var(--gray-400)]">
        <span className="chip-active relative">One Way<span className="absolute -bottom-[15px] left-0 right-0 h-[2px] bg-[var(--green-700)]" /></span>
        <span>Round Trip</span><span>Multi City</span>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-[1fr_auto_1fr_1fr_1fr_auto] gap-3 md:gap-0 items-end">
        <Field label={<span className="flex items-center gap-1"><MapPin size={11} />From</span>}>
          <Select value={from} onChange={(e) => setFrom(e.target.value)} className="md:border-none md:pl-0 font-bold">{cities.map((c) => <option key={c}>{c}</option>)}</Select>
        </Field>
        <button onClick={swap} aria-label="Swap origin and destination" className="hidden md:flex w-9 h-9 rounded-full border border-[var(--line)] items-center justify-center text-[var(--green-700)] mx-1.5 focus-ring hover:bg-[var(--green-100)]"><ArrowRightLeft size={15} /></button>
        <Field label={<span className="flex items-center gap-1"><MapPin size={11} />To</span>}>
          <Select value={to} onChange={(e) => setTo(e.target.value)} className="md:border-none md:pl-0 font-bold">{cities.map((c) => <option key={c}>{c}</option>)}</Select>
        </Field>
        <Field label={<span className="flex items-center gap-1"><Calendar size={11} />Departure</span>}>
          <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="md:border-none md:pl-0 font-bold" min={new Date().toISOString().slice(0, 10)} />
        </Field>
        <Field label={<span className="flex items-center gap-1"><User size={11} />Passengers</span>}>
          <Select value={passengers} onChange={(e) => setPassengers(+e.target.value)} className="md:border-none md:pl-0 font-bold">{[1, 2, 3, 4, 5].map((n) => <option key={n} value={n}>{n} Passenger{n > 1 ? "s" : ""}</option>)}</Select>
        </Field>
        <Button size="lg" className="ml-0 md:ml-4 w-full md:w-auto" onClick={() => onSearch({ from, to, date, passengers })}><Search size={16} />Search Buses</Button>
      </div>
    </div>
  );
}
