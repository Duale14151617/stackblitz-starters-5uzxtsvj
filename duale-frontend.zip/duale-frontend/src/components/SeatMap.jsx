import React, { useState } from "react";
import { Button } from "./ui";
import { cls } from "../lib/helpers";
import { useApi } from "../context/DataContext";

export default function SeatMap({ tripId, count, onConfirm }) {
  const { api } = useApi();
  const { total, taken } = api.getSeatsForTrip(tripId);
  const [selected, setSelected] = useState([]);
  const toggle = (n) => {
    if (taken.includes(n)) return;
    setSelected((s) => (s.includes(n) ? s.filter((x) => x !== n) : s.length < count ? [...s, n] : s));
  };
  const rows = Math.ceil(total / 4);

  const Seat = ({ n }) => {
    if (n > total) return <div />;
    const isTaken = taken.includes(n), isSel = selected.includes(n);
    return (
      <button onClick={() => toggle(n)} disabled={isTaken}
        className={cls("seat h-10 rounded-lg text-xs font-bold focus-ring",
          isTaken ? "seat-taken bg-gray-300 text-gray-400 cursor-not-allowed" : isSel ? "bg-[var(--green-700)] text-white" : "bg-[var(--line)] text-[var(--ink)] hover:bg-[var(--green-100)]")}>
        {n}
      </button>
    );
  };

  return (
    <div>
      <div className="flex items-center gap-5 text-xs text-[var(--gray-600)] mb-5">
        <span className="flex items-center gap-1.5"><span className="w-3.5 h-3.5 rounded bg-[var(--line)] inline-block" />Available</span>
        <span className="flex items-center gap-1.5"><span className="w-3.5 h-3.5 rounded bg-[var(--green-700)] inline-block" />Selected</span>
        <span className="flex items-center gap-1.5"><span className="w-3.5 h-3.5 rounded bg-gray-300 inline-block" />Taken</span>
      </div>
      <div className="max-w-xs mx-auto grid grid-cols-5 gap-2.5">
        {Array.from({ length: rows }).map((_, row) => (
          <React.Fragment key={row}>
            <Seat n={row * 4 + 1} /><Seat n={row * 4 + 2} /><div aria-hidden="true" /><Seat n={row * 4 + 3} /><Seat n={row * 4 + 4} />
          </React.Fragment>
        ))}
      </div>
      <div className="mt-6 flex items-center justify-between">
        <span className="text-sm text-[var(--gray-600)]">{selected.length}/{count} seat{count > 1 ? "s" : ""} selected</span>
        <Button disabled={selected.length !== count} onClick={() => onConfirm(selected)}>Continue</Button>
      </div>
    </div>
  );
}
