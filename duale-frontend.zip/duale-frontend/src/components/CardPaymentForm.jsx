import React, { useState } from "react";
import { CardElement, useStripe, useElements } from "@stripe/react-stripe-js";
import { AlertCircle } from "lucide-react";
import { Button } from "./ui";

/**
 * Collects card details and confirms the PaymentIntent directly with
 * Stripe — the card number never touches our PHP backend. `clientSecret`
 * comes from POST /api/payments/process.php (method: "Card"), which created
 * the PaymentIntent server-side using the secret key.
 */
export default function CardPaymentForm({ clientSecret, amountLabel, onConfirmed, onFailed }) {
  const stripe = useStripe();
  const elements = useElements();
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const submit = async (e) => {
    e.preventDefault();
    if (!stripe || !elements) return;
    setBusy(true);
    setErr("");
    const { error, paymentIntent } = await stripe.confirmCardPayment(clientSecret, {
      payment_method: { card: elements.getElement(CardElement) },
    });
    setBusy(false);
    if (error) {
      setErr(error.message || "Card payment failed.");
      return;
    }
    if (paymentIntent?.status === "succeeded" || paymentIntent?.status === "processing") {
      onConfirmed();
    } else {
      setErr("Payment was not completed.");
      onFailed?.();
    }
  };

  return (
    <form onSubmit={submit} className="space-y-4">
      <div className="border border-[var(--line)] rounded-lg px-3.5 py-3.5 bg-white">
        <CardElement options={{ style: { base: { fontSize: "15px", color: "#101815", "::placeholder": { color: "#8b948e" } } } }} />
      </div>
      {err && <p className="text-sm text-red-600 flex items-center gap-1.5"><AlertCircle size={14} />{err}</p>}
      <Button type="submit" className="w-full" disabled={!stripe} loading={busy}>Pay {amountLabel}</Button>
    </form>
  );
}
