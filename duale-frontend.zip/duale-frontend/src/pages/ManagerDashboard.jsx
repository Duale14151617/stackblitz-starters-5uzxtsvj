import React, { useState } from "react";
import { BarChart3, Bus, Route as RouteIcon, Calendar, DollarSign, Ticket, FileText, TrendingUp, Settings, Users } from "lucide-react";
import DashboardShell from "../components/DashboardShell";
import { Tabs } from "../components/ui";
import {
  AnalyticsTab, BusesTab, RoutesTab, SchedulesTab, PricingTab,
  AgentsTab, ReportsTab, RevenueTab, SettingsTab, UsersTab,
} from "./manager/ManagerTabs";

export default function ManagerDashboard() {
  const [tab, setTab] = useState("analytics");
  const tabs = [
    { key: "analytics", label: "Analytics", icon: BarChart3 },
    { key: "buses", label: "Buses", icon: Bus },
    { key: "routes", label: "Routes", icon: RouteIcon },
    { key: "schedules", label: "Schedules", icon: Calendar },
    { key: "pricing", label: "Pricing", icon: DollarSign },
    { key: "agents", label: "Agents", icon: Ticket },
    { key: "reports", label: "Reports", icon: FileText },
    { key: "revenue", label: "Revenue", icon: TrendingUp },
    { key: "settings", label: "Settings", icon: Settings },
    { key: "users", label: "Users", icon: Users },
  ];
  return (
    <DashboardShell tabs={tabs} active={tab} onChange={setTab} title="Manager Console">
      <div className="mb-6"><Tabs tabs={tabs} active={tab} onChange={setTab} /></div>
      {tab === "analytics" && <AnalyticsTab />}
      {tab === "buses" && <BusesTab />}
      {tab === "routes" && <RoutesTab />}
      {tab === "schedules" && <SchedulesTab />}
      {tab === "pricing" && <PricingTab />}
      {tab === "agents" && <AgentsTab />}
      {tab === "reports" && <ReportsTab />}
      {tab === "revenue" && <RevenueTab />}
      {tab === "settings" && <SettingsTab />}
      {tab === "users" && <UsersTab />}
    </DashboardShell>
  );
}
