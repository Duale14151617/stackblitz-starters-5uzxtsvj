import React, { useMemo, useState } from "react";
import { Ticket, MapPinned, Bell, User, Search, AlertCircle, CheckCircle2 } from "lucide-react";
import DashboardShell from "../components/DashboardShell";
import { Tabs, Card, Badge, Button, Field, Input, EmptyState, Select } from "../components/ui";
import { fmtDate, fmtTime, money } from "../lib/helpers";
import { useApi } from "../context/DataContext";
import { useAuth } from "../context/AuthContext";

export default function CustomerDashboard({ goBook }) {
  const { api } = useApi();
  const { user } = useAuth();
  const [tab, setTab] = useState("bookings");
  const bookings = api.getBookingsForUser(user.id);
  const notifications = api.getNotifications(user.id);
  const [profile, setProfile] = useState({ name: user.name, phone: user.phone });
  const [saved, setSaved] = useState(false);
  const tabs = [
    { key: "bookings", label: "My Bookings", icon: Ticket },
    { key: "track", label: "Track Bus", icon: MapPinned },
    { key: "notifications", label: "Notifications", icon: Bell },
    { key: "profile", label: "Profile", icon: User },
  ];

  return (
    <DashboardShell tabs={tabs} active={tab} onChange={setTab} title="My Account">
      <div className="mb-6"><Tabs tabs={tabs} active={tab} onChange={setTab} /></div>

      {tab === "bookings" && (
        <div className="space-y-4">
          <div className="flex justify-between items-center mb-2">
            <p className="text-sm text-[var(--gray-600)]">{bookings.length} booking(s)</p>
            <Button size="sm" onClick={goBook}><Search size={14} />Book a new trip</Button>
          </div>
          {bookings.length === 0 ? <EmptyState icon={Ticket} title="No bookings yet" sub="Search for a route to make your first booking." /> :
            bookings.map((b) => {
              const trip = api.getTrip(b.tripId); const route = api.getRoute(trip.routeId);
              return (
                <Card key={b.id} className="p-5 flex flex-col sm:flex-row justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold">{route.from} → {route.to}</span>
                      <Badge tone={b.status === "cancelled" ? "danger" : b.checkedIn ? "success" : "neutral"}>{b.status === "cancelled" ? "Cancelled" : b.checkedIn ? "Checked in" : "Confirmed"}</Badge>
                    </div>
                    <div className="text-sm text-[var(--gray-600)] mt-1">{fmtDate(trip.departure)} · {fmtTime(trip.departure)} · Seats {b.seats.join(", ")}</div>
                    <div className="text-xs text-[var(--gray-400)] mt-1">Ref {b.ref}</div>
                  </div>
                  <div className="flex items-center gap-4">
                    <img alt="QR ticket" src={`https://api.qrserver.com/v1/create-qr-code/?size=64x64&data=${encodeURIComponent(b.ref)}`} className="rounded border border-[var(--line)]" />
                    <div className="text-right">
                      <div className="font-bold text-[var(--green-700)]">{money(b.amount)}</div>
                      {b.status !== "cancelled" && <button onClick={() => api.cancelBooking(b.id)} className="text-xs text-red-500 font-semibold mt-1 focus-ring">Cancel</button>}
                    </div>
                  </div>
                </Card>
              );
            })}
        </div>
      )}

      {tab === "track" && <TrackBus bookings={bookings.filter((b) => b.status !== "cancelled")} />}

      {tab === "notifications" && (
        <div className="space-y-3">
          {notifications.length === 0 ? <EmptyState icon={Bell} title="No notifications" /> :
            notifications.map((n) => (
              <Card key={n.id} className={`p-4 flex gap-3 ${!n.read ? "border-[var(--green-500)]" : ""}`}>
                <Bell size={16} className="text-[var(--green-600)] mt-0.5 shrink-0" />
                <div><p className="text-sm">{n.message}</p><p className="text-xs text-[var(--gray-400)] mt-1">{new Date(n.createdAt).toLocaleString()}</p></div>
              </Card>
            ))}
        </div>
      )}

      {tab === "profile" && (
        <Card className="p-6 max-w-md">
          <div className="space-y-4">
            <Field label="Full name"><Input value={profile.name} onChange={(e) => setProfile({ ...profile, name: e.target.value })} /></Field>
            <Field label="Email" hint="Managed via your account — not editable here."><Input value={user.email} disabled /></Field>
            <Field label="Phone"><Input value={profile.phone || ""} onChange={(e) => setProfile({ ...profile, phone: e.target.value })} /></Field>
            <Button onClick={async () => { await api.updateProfile(user.id, profile); setSaved(true); setTimeout(() => setSaved(false), 2000); }}>Save changes</Button>
            {saved && <p className="text-sm text-[var(--green-700)] flex items-center gap-1.5"><CheckCircle2 size={14} />Saved</p>}
          </div>
        </Card>
      )}
    </DashboardShell>
  );
}

function TrackBus({ bookings }) {
  const { api } = useApi();
  const [selected, setSelected] = useState(bookings[0]?.id || "");
  const booking = bookings.find((b) => b.id === selected);
  const trip = booking && api.getTrip(booking.tripId);
  const route = trip && api.getRoute(trip.routeId);
  const progress = useMemo(() => {
    if (!trip) return 0;
    const now = Date.now(), dep = new Date(trip.departure).getTime(), arr = new Date(trip.arrival).getTime();
    if (now < dep) return 0;
    if (now > arr) return 100;
    return Math.round(((now - dep) / (arr - dep)) * 100);
  }, [trip]);

  if (!bookings.length) return <EmptyState icon={MapPinned} title="No active trips to track" />;

  return (
    <Card className="p-6">
      <Field label="Select a booking">
        <Select value={selected} onChange={(e) => setSelected(e.target.value)}>
          {bookings.map((b) => { const t = api.getTrip(b.tripId), r = api.getRoute(t.routeId); return <option key={b.id} value={b.id}>{r.from} → {r.to} · {fmtDate(t.departure)} · {b.ref}</option>; })}
        </Select>
      </Field>
      {trip && (
        <div className="mt-6">
          <div className="flex justify-between text-sm font-semibold mb-2"><span>{route.from}</span><span>{route.to}</span></div>
          <div className="h-2.5 rounded-full bg-[var(--line)] overflow-hidden"><div className="h-full bg-[var(--green-600)] transition-all duration-700" style={{ width: `${progress}%` }} /></div>
          <div className="flex justify-between text-xs text-[var(--gray-400)] mt-2"><span>{progress === 0 ? "Not yet departed" : progress === 100 ? "Arrived" : `${progress}% of the way there`}</span><span>ETA {fmtTime(trip.arrival)}</span></div>
          <p className="text-xs text-[var(--gray-400)] mt-4 flex items-start gap-1.5"><AlertCircle size={13} className="mt-0.5 shrink-0" />Live GPS tracking requires a telematics feed from the bus fleet — this simulates position from schedule times as a placeholder.</p>
        </div>
      )}
    </Card>
  );
}
