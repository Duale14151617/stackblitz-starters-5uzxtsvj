import React, { useState } from "react";
import { Plus, Ticket, UserCheck, Wallet, DollarSign, ChevronRight, AlertCircle, CheckCircle2 } from "lucide-react";
import DashboardShell from "../components/DashboardShell";
import { Tabs, Card, Badge, Button, Field, Input, DataTable, StatCard } from "../components/ui";
import { money } from "../lib/helpers";
import { useApi } from "../context/DataContext";
import { useAuth } from "../context/AuthContext";

export default function AgentDashboard({ startWalkInBooking }) {
  const { api } = useApi();
  const { user } = useAuth();
  const [tab, setTab] = useState("new");
  const [checkinRef, setCheckinRef] = useState("");
  const [checkinMsg, setCheckinMsg] = useState(null);
  const bookings = api.getBookingsForAgent(user.id);
  const commission = bookings.filter((b) => b.status !== "cancelled").reduce((s, b) => s + b.amount * (user.commissionRate || 0.06), 0);
  const tabs = [
    { key: "new", label: "New Booking", icon: Plus },
    { key: "bookings", label: "Bookings", icon: Ticket },
    { key: "checkin", label: "Check-in", icon: UserCheck },
    { key: "commissions", label: "Commissions", icon: Wallet },
  ];

  const doCheckin = async () => {
    const res = await api.checkInBooking(checkinRef.trim());
    setCheckinMsg(res.error ? { error: res.error } : { ok: `${res.booking.ref} checked in successfully.` });
  };

  return (
    <DashboardShell tabs={tabs} active={tab} onChange={setTab} title="Agent Console">
      <div className="mb-6"><Tabs tabs={tabs} active={tab} onChange={setTab} /></div>

      {tab === "new" && (
        <Card className="p-8 text-center max-w-md mx-auto">
          <Ticket size={30} className="mx-auto text-[var(--green-600)] mb-3" />
          <h3 className="font-bold text-lg">Create a walk-in booking</h3>
          <p className="text-sm text-[var(--gray-600)] mt-1 mb-5">Search a route, pick seats and collect payment for a customer at the counter.</p>
          <Button size="lg" onClick={startWalkInBooking}>Start new booking<ChevronRight size={15} /></Button>
        </Card>
      )}

      {tab === "bookings" && (
        <DataTable
          columns={[
            { key: "ref", label: "Ref" },
            { key: "route", label: "Route", render: (b) => { const t = api.getTrip(b.tripId), r = api.getRoute(t.routeId); return `${r.from} → ${r.to}`; } },
            { key: "customer", label: "Customer", render: (b) => b.walkIn?.name || "Registered customer" },
            { key: "seats", label: "Seats", render: (b) => b.seats.join(", ") },
            { key: "amount", label: "Amount", render: (b) => money(b.amount) },
            { key: "status", label: "Status", render: (b) => <Badge tone={b.status === "cancelled" ? "danger" : b.checkedIn ? "success" : "neutral"}>{b.status === "cancelled" ? "Cancelled" : b.checkedIn ? "Checked in" : "Confirmed"}</Badge> },
          ]}
          rows={bookings}
        />
      )}

      {tab === "checkin" && (
        <Card className="p-6 max-w-md">
          <h3 className="font-bold mb-4">Passenger check-in</h3>
          <Field label="Booking reference or QR code value">
            <div className="flex gap-2"><Input value={checkinRef} onChange={(e) => setCheckinRef(e.target.value)} placeholder="e.g. DL-AB12CD" /><Button onClick={doCheckin}><UserCheck size={15} />Check in</Button></div>
          </Field>
          {checkinMsg && <p className={`text-sm mt-3 flex items-center gap-1.5 ${checkinMsg.error ? "text-red-600" : "text-[var(--green-700)]"}`}>{checkinMsg.error ? <AlertCircle size={14} /> : <CheckCircle2 size={14} />}{checkinMsg.error || checkinMsg.ok}</p>}
        </Card>
      )}

      {tab === "commissions" && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <StatCard icon={Ticket} label="Bookings made" value={bookings.length} />
          <StatCard icon={DollarSign} label="Total sales" value={money(bookings.reduce((s, b) => s + b.amount, 0))} />
          <StatCard icon={Wallet} label="Commission earned" value={money(commission)} sub={`${((user.commissionRate || 0.06) * 100).toFixed(0)}% rate`} />
        </div>
      )}
    </DashboardShell>
  );
}
