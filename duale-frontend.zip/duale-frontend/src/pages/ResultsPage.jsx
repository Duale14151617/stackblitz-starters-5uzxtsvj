import React from "react";
import { Bus, ChevronLeft, ChevronRight } from "lucide-react";
import { Card, Button, EmptyState } from "../components/ui";
import { fmtDate, fmtTime, money } from "../lib/helpers";
import { useApi } from "../context/DataContext";

export default function ResultsPage({ query, onSelectTrip, onBack }) {
  const { api } = useApi();
  const trips = api.searchTrips(query.from, query.to, query.date);

  return (
    <section className="max-w-[1000px] mx-auto px-6 py-10 fade-in">
      <button onClick={onBack} className="text-sm font-semibold text-[var(--green-700)] flex items-center gap-1 mb-4 focus-ring"><ChevronLeft size={15} />Back to search</button>
      <h2 className="text-2xl font-extrabold mb-1">{query.from} <ChevronRight size={16} className="inline text-[var(--green-600)]" /> {query.to}</h2>
      <p className="text-[var(--gray-600)] mb-6 text-sm">{fmtDate(query.date)} · {query.passengers} passenger{query.passengers > 1 ? "s" : ""}</p>
      {trips.length === 0 ? (
        <EmptyState icon={Bus} title="No trips found for that date" sub="Try another date or route." />
      ) : (
        <div className="space-y-3">
          {trips.map((t) => {
            const bus = api.getBus(t.busId);
            const { total, taken } = api.getSeatsForTrip(t.id);
            const available = total - taken.length;
            return (
              <Card key={t.id} hover className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-5">
                  <div className="w-11 h-11 rounded-xl bg-[var(--green-100)] text-[var(--green-700)] flex items-center justify-center shrink-0"><Bus size={20} /></div>
                  <div>
                    <div className="font-bold">{fmtTime(t.departure)} → {fmtTime(t.arrival)}</div>
                    <div className="text-sm text-[var(--gray-600)]">{bus?.model} · {bus?.amenities?.join(", ")}</div>
                    <div className="text-xs text-[var(--gray-400)] mt-1">{available > 0 ? `${available} seats left` : "Sold out"}</div>
                  </div>
                </div>
                <div className="flex items-center gap-4 sm:gap-6">
                  <div className="text-right"><div className="text-xl font-extrabold text-[var(--green-700)]">{money(t.price)}</div><div className="text-xs text-[var(--gray-400)]">per seat</div></div>
                  <Button disabled={available <= 0} onClick={() => onSelectTrip(t)}>Select seats</Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </section>
  );
}
