import React from "react";
import { Bus, MapPin, Users, Star, Shield, ChevronRight, Ticket, Headphones } from "lucide-react";
import { Card, StatCard, EmptyState } from "../components/ui";
import SearchWidget from "../components/SearchWidget";
import { addDays, money } from "../lib/helpers";
import { useApi } from "../context/DataContext";

export default function HomePage({ onSearch }) {
  const { api } = useApi();
  const routes = api.getRoutes();

  return (
    <>
      <section className="relative overflow-hidden" style={{ background: `linear-gradient(100deg, rgba(9,38,26,.90) 0%, rgba(9,38,26,.55) 45%, rgba(9,38,26,.08) 100%), url('https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?q=80&w=1740&auto=format&fit=crop') center/cover no-repeat` }}>
        <div className="max-w-[1280px] mx-auto px-6 pt-14 pb-28 md:pb-36 relative">
          <span className="inline-block bg-[rgba(34,163,94,.18)] border border-[rgba(34,163,94,.55)] text-[#7fe3ac] text-xs font-bold tracking-wider px-4 py-1.5 rounded-full mb-5 fade-in">SAFE • COMFORTABLE • RELIABLE</span>
          <h1 className="text-white font-extrabold text-4xl md:text-6xl leading-[1.05] -tracking-wide max-w-xl fade-in">Your Journey,<br /><span className="text-[#5bd68a]">Our Priority.</span></h1>
          <p className="text-[#d8e6de] text-[17px] mt-5 max-w-md leading-relaxed fade-in">Book your bus tickets easily, travel safely and enjoy the best experience with Du&apos;ale.</p>
          <div className="mt-9 max-w-[1000px] slide-up"><SearchWidget onSearch={onSearch} /></div>
        </div>
      </section>

      <section className="max-w-[1280px] mx-auto px-6 pt-10 md:-mt-24 relative pb-16">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {[
            { icon: Bus, num: `${Math.max(api.getBuses().length, 1) * 80}+`, label: "Daily Trips" },
            { icon: MapPin, num: `${new Set(routes.flatMap((r) => [r.from, r.to])).size}+`, label: "Destinations" },
            { icon: Users, num: "500K+", label: "Happy Passengers" },
            { icon: Star, num: "10+", label: "Years of Service" },
            { icon: Shield, num: "4.8/5", label: "Customer Rating" },
          ].map((s, i) => <StatCard key={i} icon={s.icon} value={s.num} label={s.label} />)}
        </div>
      </section>

      <section className="max-w-[1280px] mx-auto px-6 pb-16">
        <div className="text-[var(--green-600)] text-xs font-bold tracking-wider uppercase mb-2">Popular Routes</div>
        <h2 className="text-3xl font-extrabold -tracking-wide max-w-md mb-2">Top Routes for You</h2>
        <p className="text-[var(--gray-600)] max-w-md mb-6">Choose from our most popular routes and book your journey in a few clicks.</p>
        {routes.length === 0 ? (
          <EmptyState icon={Bus} title="No routes yet" sub="Import backend/db/schema.sql to seed sample routes." />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {routes.map((r) => (
              <Card key={r.id} hover className="overflow-hidden">
                <img src={r.image} alt={`${r.from} to ${r.to}`} className="h-36 w-full object-cover" />
                <div className="p-4">
                  <div className="font-bold flex items-center gap-1.5 text-[15px]">{r.from} <ChevronRight size={14} className="text-[var(--green-600)]" /> {r.to}</div>
                  <div className="text-sm text-[var(--gray-600)] mt-2">From <b className="text-[var(--green-700)] text-base">{money(r.basePrice)}</b></div>
                  <button onClick={() => onSearch({ from: r.from, to: r.to, date: addDays(new Date(), 1).toISOString().slice(0, 10), passengers: 1 })}
                    className="mt-3 w-full text-sm font-semibold text-[var(--green-700)] flex items-center justify-center gap-1 border border-[var(--line)] rounded-lg py-2 hover:bg-[var(--green-100)] focus-ring">
                    View trips <ChevronRight size={14} />
                  </button>
                </div>
              </Card>
            ))}
          </div>
        )}
      </section>

      <section className="max-w-[1280px] mx-auto px-6 pb-20 grid grid-cols-1 lg:grid-cols-[1.1fr_1fr] gap-6">
        <div className="bg-[var(--green-100)] rounded-2xl p-8 grid grid-cols-1 sm:grid-cols-2 gap-8">
          {[
            { icon: Bus, t: "Comfortable Buses", d: "Modern buses with extra legroom and amenities" },
            { icon: Shield, t: "Safe & Secure", d: "Your safety is our top priority on every trip" },
            { icon: Ticket, t: "Easy Booking", d: "Book your tickets online in just a few clicks" },
            { icon: Headphones, t: "24/7 Support", d: "We're here to help you anytime, anywhere" },
          ].map((f, i) => (
            <div key={i}>
              <div className="w-11 h-11 rounded-xl bg-white text-[var(--green-700)] flex items-center justify-center mb-3"><f.icon size={19} /></div>
              <h4 className="font-bold text-[15.5px]">{f.t}</h4>
              <p className="text-[13.3px] text-[var(--gray-600)] mt-1.5 leading-relaxed">{f.d}</p>
            </div>
          ))}
        </div>
        <div className="rounded-2xl p-8 text-white flex flex-col justify-center" style={{ background: "linear-gradient(135deg, var(--green-900), #093022)" }}>
          <h3 className="text-2xl font-extrabold max-w-[260px] leading-tight">Download Our App</h3>
          <p className="text-[13.5px] text-[#c9dccf] mt-3 max-w-[250px] leading-relaxed">Book tickets, track your bus and get exclusive offers on the go.</p>
        </div>
      </section>
    </>
  );
}
