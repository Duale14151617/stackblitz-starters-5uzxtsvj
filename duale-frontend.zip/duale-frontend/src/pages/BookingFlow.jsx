import React, { useState } from "react";
import { Elements } from "@stripe/react-stripe-js";
import { Check, ChevronLeft, AlertCircle, Wallet, CheckCircle2, Printer, Loader2 } from "lucide-react";
import { Card, Field, Input, Select, Button } from "../components/ui";
import SeatMap from "../components/SeatMap";
import CardPaymentForm from "../components/CardPaymentForm";
import { fmtDate, fmtTime, money, cls } from "../lib/helpers";
import { useApi } from "../context/DataContext";
import { stripePromise } from "../lib/stripe";

const PAY_METHODS = ["EVC Plus", "Golis Sahal", "Card"];

export default function BookingFlow({ trip, passengerCount, actingAsAgent, onDone, onCancel }) {
  const { api } = useApi();
  const [step, setStep] = useState("seats");
  const [seats, setSeats] = useState([]);
  const [passengers, setPassengers] = useState(Array.from({ length: passengerCount }, () => ({ name: "", age: "", gender: "Male" })));
  const [walkIn, setWalkIn] = useState({ name: "", phone: "" });
  const [payMethod, setPayMethod] = useState("EVC Plus");
  const [phoneNumber, setPhoneNumber] = useState("");

  const [pendingBooking, setPendingBooking] = useState(null); // the reserved (unpaid) row
  const [reserving, setReserving] = useState(false);
  const [charging, setCharging] = useState(false);
  const [confirming, setConfirming] = useState(false); // waiting on the Stripe webhook
  const [cardSecret, setCardSecret] = useState(null);
  const [error, setError] = useState("");
  const [booking, setBooking] = useState(null); // final, confirmed booking

  const route = api.getRoute(trip.routeId);
  const amount = trip.price * passengerCount;
  const steps = ["seats", "details", "payment", "done"];
  const stepIdx = steps.indexOf(step);

  // Step 1 of payment: reserve the seats the instant the person reaches the
  // payment screen. This is what actually prevents double-booking — the row
  // exists (status 'pending') from this point on, so no one else can take
  // these seats while this person is choosing how to pay.
  const goToPayment = async () => {
    setError("");
    setReserving(true);
    try {
      const b = await api.createPendingBooking({
        tripId: trip.id, seats, passengers,
        asAgent: actingAsAgent, walkIn: actingAsAgent ? walkIn : null,
      });
      setPendingBooking(b);
      setStep("payment");
    } catch (e) {
      // Most likely someone else took one of these seats in the meantime.
      setError(e.message || "Could not reserve those seats.");
      setSeats([]);
      setStep("seats");
    }
    setReserving(false);
  };

  const chargeMobileMoney = async () => {
    setError(""); setCharging(true);
    try {
      const result = await api.payForBooking({ bookingId: pendingBooking.id, method: payMethod, phoneNumber });
      setBooking(result.booking);
      setStep("done");
    } catch (e) {
      setError(e.message || "Payment failed. Please try again.");
      // The server already cancelled the pending booking on failure, which
      // frees the seats — a retry needs a fresh reservation.
      setPendingBooking(null);
    }
    setCharging(false);
  };

  const startCardPayment = async () => {
    setError(""); setCharging(true);
    try {
      const result = await api.payForBooking({ bookingId: pendingBooking.id, method: "Card" });
      setCardSecret(result.clientSecret);
    } catch (e) {
      setError(e.message || "Could not start card payment.");
      setPendingBooking(null);
    }
    setCharging(false);
  };

  // Stripe confirms the card with Stripe directly (handled in
  // CardPaymentForm); once that succeeds, the booking itself is finalized
  // asynchronously by the Stripe webhook hitting our backend — so we poll
  // briefly for that to land rather than assuming it already has.
  const onCardConfirmed = async () => {
    setConfirming(true);
    for (let i = 0; i < 8; i++) {
      await new Promise((r) => setTimeout(r, 1500));
      await api.confirmCardPayment(pendingBooking.id);
      const fresh = await api.refreshBooking(pendingBooking.id);
      if (fresh && fresh.status === "confirmed") { setBooking(fresh); setConfirming(false); setStep("done"); return; }
      if (fresh && fresh.status === "cancelled") { setConfirming(false); setError("The payment could not be confirmed. Please try again."); setPendingBooking(null); return; }
    }
    // Still pending after ~12s — don't block the UI forever; the webhook
    // will land shortly and the booking will show as confirmed in
    // "My Bookings" once it does.
    setConfirming(false);
    setError("Your payment is still being confirmed. Check \u201cMy Bookings\u201d in a moment \u2014 it will update automatically once confirmed.");
  };

  return (
    <section className="max-w-[720px] mx-auto px-6 py-10 fade-in">
      <div className="flex items-center gap-2 mb-8">
        {steps.map((s, i) => (
          <React.Fragment key={s}>
            <div className={cls("w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold", i <= stepIdx ? "bg-[var(--green-700)] text-white" : "bg-[var(--line)] text-[var(--gray-400)]")}>{i < stepIdx ? <Check size={13} /> : i + 1}</div>
            {i < steps.length - 1 && <div className={cls("flex-1 h-[2px]", i < stepIdx ? "bg-[var(--green-700)]" : "bg-[var(--line)]")} />}
          </React.Fragment>
        ))}
      </div>

      {step === "seats" && (
        <Card className="p-6">
          <h3 className="font-bold text-lg mb-1">Choose your seats</h3>
          <p className="text-sm text-[var(--gray-600)] mb-5">{route.from} → {route.to} · {fmtDate(trip.departure)} · {fmtTime(trip.departure)}</p>
          {error && <p className="text-sm text-red-600 mb-4 flex items-center gap-1.5"><AlertCircle size={14} />{error}</p>}
          <SeatMap tripId={trip.id} count={passengerCount} onConfirm={(s) => { setSeats(s); setStep("details"); }} />
        </Card>
      )}

      {step === "details" && (
        <Card className="p-6">
          <h3 className="font-bold text-lg mb-5">Passenger details</h3>
          {actingAsAgent && (
            <div className="grid grid-cols-2 gap-4 mb-6 pb-6 border-b border-[var(--line)]">
              <Field label="Walk-in customer name"><Input value={walkIn.name} onChange={(e) => setWalkIn({ ...walkIn, name: e.target.value })} /></Field>
              <Field label="Phone number"><Input value={walkIn.phone} onChange={(e) => setWalkIn({ ...walkIn, phone: e.target.value })} placeholder="+252 6..." /></Field>
            </div>
          )}
          <div className="space-y-4">
            {passengers.map((p, i) => (
              <div key={i} className="grid grid-cols-[1fr_90px_110px] gap-3 items-end">
                <Field label={`Passenger ${i + 1} (seat ${seats[i]})`}><Input value={p.name} onChange={(e) => { const arr = [...passengers]; arr[i].name = e.target.value; setPassengers(arr); }} required /></Field>
                <Field label="Age"><Input type="number" min="0" value={p.age} onChange={(e) => { const arr = [...passengers]; arr[i].age = e.target.value; setPassengers(arr); }} /></Field>
                <Field label="Gender"><Select value={p.gender} onChange={(e) => { const arr = [...passengers]; arr[i].gender = e.target.value; setPassengers(arr); }}><option>Male</option><option>Female</option></Select></Field>
              </div>
            ))}
          </div>
          <div className="flex justify-between mt-7">
            <Button variant="ghost" onClick={() => setStep("seats")}><ChevronLeft size={15} />Back</Button>
            <Button
              loading={reserving}
              disabled={passengers.some((p) => !p.name) || (actingAsAgent && (!walkIn.name || !walkIn.phone))}
              onClick={goToPayment}
            >
              Continue to payment
            </Button>
          </div>
        </Card>
      )}

      {step === "payment" && pendingBooking && (
        <Card className="p-6">
          <h3 className="font-bold text-lg mb-5">Payment</h3>
          <div className="bg-[var(--cream)] rounded-xl p-4 mb-6 flex justify-between text-sm">
            <span className="text-[var(--gray-600)]">{passengerCount} seat(s) × {money(trip.price)}</span>
            <span className="font-bold text-lg text-[var(--green-700)]">{money(amount)}</span>
          </div>

          <div className="grid grid-cols-3 gap-3 mb-6">
            {PAY_METHODS.map((m) => (
              <button key={m} onClick={() => { setPayMethod(m); setCardSecret(null); setError(""); }}
                className={cls("border rounded-xl p-4 text-sm font-semibold flex flex-col items-center gap-2 focus-ring", payMethod === m ? "border-[var(--green-700)] bg-[var(--green-100)] text-[var(--green-700)]" : "border-[var(--line)] hover:bg-gray-50")}>
                <Wallet size={18} />{m}
              </button>
            ))}
          </div>

          {error && <p className="text-sm text-red-600 mb-4 flex items-center gap-1.5"><AlertCircle size={14} />{error}</p>}

          {payMethod !== "Card" && (
            <>
              <Field label={`${payMethod} phone number`} hint="You'll get a prompt on this phone to approve the charge.">
                <Input value={phoneNumber} onChange={(e) => setPhoneNumber(e.target.value)} placeholder="+252 61 ..." />
              </Field>
              <div className="flex justify-between mt-6">
                <Button variant="ghost" onClick={() => setStep("details")} disabled={charging}><ChevronLeft size={15} />Back</Button>
                <Button onClick={chargeMobileMoney} loading={charging} disabled={!phoneNumber}>Pay {money(amount)}</Button>
              </div>
            </>
          )}

          {payMethod === "Card" && !cardSecret && (
            <div className="flex flex-col items-center gap-4 py-2">
              <p className="text-sm text-[var(--gray-600)] text-center">Card details are entered on the next step and go straight to Stripe — they never pass through our server.</p>
              <Button onClick={startCardPayment} loading={charging} className="w-full">Continue to card details</Button>
              <Button variant="ghost" onClick={() => setStep("details")} disabled={charging}><ChevronLeft size={15} />Back</Button>
            </div>
          )}

          {payMethod === "Card" && cardSecret && !confirming && (
            <Elements stripe={stripePromise} options={{ clientSecret: cardSecret }}>
              <CardPaymentForm clientSecret={cardSecret} amountLabel={money(amount)} onConfirmed={onCardConfirmed} />
            </Elements>
          )}

          {confirming && (
            <div className="flex flex-col items-center gap-3 py-6 text-[var(--gray-600)] text-sm">
              <Loader2 className="spin" size={22} />
              Confirming your payment…
            </div>
          )}
        </Card>
      )}

      {step === "done" && booking && (
        <Card className="p-8 text-center slide-up">
          <div className="w-14 h-14 rounded-full bg-[var(--green-100)] text-[var(--green-700)] flex items-center justify-center mx-auto mb-4"><CheckCircle2 size={28} /></div>
          <h3 className="font-extrabold text-xl">Booking confirmed!</h3>
          <p className="text-[var(--gray-600)] text-sm mt-1">Reference <b>{booking.ref}</b></p>
          <img alt="Ticket QR code" className="mx-auto my-6 rounded-lg border border-[var(--line)]" src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(booking.ref)}`} />
          <div className="text-sm text-left bg-[var(--cream)] rounded-xl p-4 space-y-1.5">
            <div className="flex justify-between"><span className="text-[var(--gray-600)]">Route</span><b>{route.from} → {route.to}</b></div>
            <div className="flex justify-between"><span className="text-[var(--gray-600)]">Departure</span><b>{fmtDate(trip.departure)}, {fmtTime(trip.departure)}</b></div>
            <div className="flex justify-between"><span className="text-[var(--gray-600)]">Seats</span><b>{seats.join(", ")}</b></div>
            <div className="flex justify-between"><span className="text-[var(--gray-600)]">Amount paid</span><b className="text-[var(--green-700)]">{money(booking.amount)}</b></div>
          </div>
          <div className="flex gap-3 mt-6">
            <Button variant="outline" className="flex-1" onClick={() => window.print()}><Printer size={15} />Print</Button>
            <Button className="flex-1" onClick={onDone}>Done</Button>
          </div>
        </Card>
      )}

      {step !== "done" && <button onClick={onCancel} className="block mx-auto text-xs text-[var(--gray-400)] mt-5 focus-ring">Cancel booking</button>}
    </section>
  );
}
