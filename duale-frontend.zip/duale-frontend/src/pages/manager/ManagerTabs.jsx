import React, { useMemo, useState } from "react";
import { Plus, Download, DollarSign, Ticket, Bus, Route as RouteIcon, TrendingUp, AlertCircle, CheckCircle2 } from "lucide-react";
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, PieChart, Pie, Cell, Legend,
} from "recharts";
import { Card, Button, Field, Input, Select, Modal, DataTable, StatCard, EmptyState, Badge } from "../../components/ui";
import { fmtDate, fmtTime, money } from "../../lib/helpers";
import { useApi } from "../../context/DataContext";

export function AnalyticsTab() {
  const { api } = useApi();
  const bookings = api.getAllBookings().filter((b) => b.status !== "cancelled");
  const revenueByDay = useMemo(() => {
    const map = {};
    bookings.forEach((b) => { const d = b.createdAt.slice(0, 10); map[d] = (map[d] || 0) + b.amount; });
    return Object.entries(map).sort().map(([date, revenue]) => ({ date: date.slice(5), revenue }));
  }, [bookings]);
  const byRoute = useMemo(() => {
    const map = {};
    bookings.forEach((b) => { const t = api.getTrip(b.tripId), r = api.getRoute(t.routeId); const key = `${r.from}→${r.to}`; map[key] = (map[key] || 0) + 1; });
    return Object.entries(map).map(([route, count]) => ({ route, count }));
  }, [bookings]);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={Ticket} label="Total bookings" value={bookings.length} />
        <StatCard icon={DollarSign} label="Total revenue" value={money(bookings.reduce((s, b) => s + b.amount, 0))} />
        <StatCard icon={Bus} label="Active buses" value={api.getBuses().length} />
        <StatCard icon={RouteIcon} label="Routes" value={api.getRoutes().length} />
      </div>
      <Card className="p-6">
        <h3 className="font-bold mb-4">Bookings by route</h3>
        <ResponsiveContainer width="100%" height={260}>
          <BarChart data={byRoute}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e3e7e2" />
            <XAxis dataKey="route" tick={{ fontSize: 12 }} />
            <YAxis tick={{ fontSize: 12 }} allowDecimals={false} />
            <Tooltip />
            <Bar dataKey="count" fill="#1a7a4c" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </Card>
      <Card className="p-6">
        <h3 className="font-bold mb-4">Revenue trend</h3>
        {revenueByDay.length === 0 ? <EmptyState title="No revenue yet" /> : (
          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={revenueByDay}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e3e7e2" />
              <XAxis dataKey="date" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip />
              <Line type="monotone" dataKey="revenue" stroke="#0d3b28" strokeWidth={2.5} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        )}
      </Card>
    </div>
  );
}

export function BusesTab() {
  const { api } = useApi();
  const [modal, setModal] = useState(null);
  const [form, setForm] = useState({ plate: "", model: "", capacity: 40, amenities: "" });
  const [busy, setBusy] = useState(false);
  const openNew = () => { setForm({ plate: "", model: "", capacity: 40, amenities: "" }); setModal({ mode: "new" }); };
  const openEdit = (b) => { setForm({ ...b, amenities: b.amenities.join(", ") }); setModal({ mode: "edit", id: b.id }); };
  const save = async () => {
    setBusy(true);
    const payload = { plate: form.plate, model: form.model, capacity: +form.capacity, amenities: form.amenities.split(",").map((s) => s.trim()).filter(Boolean) };
    if (modal.mode === "new") await api.addBus(payload); else await api.updateBus(modal.id, payload);
    setBusy(false); setModal(null);
  };
  return (
    <Card className="p-6">
      <div className="flex justify-between items-center mb-5"><h3 className="font-bold">Fleet</h3><Button size="sm" onClick={openNew}><Plus size={14} />Add bus</Button></div>
      <DataTable columns={[{ key: "plate", label: "Plate" }, { key: "model", label: "Model" }, { key: "capacity", label: "Capacity" }, { key: "amenities", label: "Amenities", render: (b) => b.amenities.join(", ") }]} rows={api.getBuses()} onEdit={openEdit} onDelete={(b) => api.deleteBus(b.id)} />
      <Modal open={!!modal} onClose={() => setModal(null)} title={modal?.mode === "new" ? "Add bus" : "Edit bus"}>
        <div className="space-y-4">
          <Field label="Plate number"><Input value={form.plate} onChange={(e) => setForm({ ...form, plate: e.target.value })} /></Field>
          <Field label="Model"><Input value={form.model} onChange={(e) => setForm({ ...form, model: e.target.value })} /></Field>
          <Field label="Capacity"><Input type="number" value={form.capacity} onChange={(e) => setForm({ ...form, capacity: e.target.value })} /></Field>
          <Field label="Amenities (comma separated)"><Input value={form.amenities} onChange={(e) => setForm({ ...form, amenities: e.target.value })} /></Field>
          <Button className="w-full" onClick={save} loading={busy}>Save bus</Button>
        </div>
      </Modal>
    </Card>
  );
}

export function RoutesTab() {
  const { api } = useApi();
  const [modal, setModal] = useState(null);
  const [form, setForm] = useState({ from: "", to: "", distanceKm: "", durationMin: "", basePrice: "" });
  const [busy, setBusy] = useState(false);
  const openNew = () => { setForm({ from: "", to: "", distanceKm: "", durationMin: "", basePrice: "" }); setModal({ mode: "new" }); };
  const openEdit = (r) => { setForm(r); setModal({ mode: "edit", id: r.id }); };
  const save = async () => {
    setBusy(true);
    const payload = { from: form.from, to: form.to, distanceKm: +form.distanceKm, durationMin: +form.durationMin, basePrice: +form.basePrice, image: form.image || "https://images.unsplash.com/photo-1519996529931-28324d5a630e?q=80&w=800&auto=format&fit=crop" };
    if (modal.mode === "new") await api.addRoute(payload); else await api.updateRoute(modal.id, payload);
    setBusy(false); setModal(null);
  };
  return (
    <Card className="p-6">
      <div className="flex justify-between items-center mb-5"><h3 className="font-bold">Routes</h3><Button size="sm" onClick={openNew}><Plus size={14} />Add route</Button></div>
      <DataTable columns={[{ key: "route", label: "Route", render: (r) => `${r.from} → ${r.to}` }, { key: "distanceKm", label: "Distance", render: (r) => `${r.distanceKm} km` }, { key: "durationMin", label: "Duration", render: (r) => `${Math.round(r.durationMin / 60)}h ${r.durationMin % 60}m` }, { key: "basePrice", label: "Base price", render: (r) => money(r.basePrice) }]} rows={api.getRoutes()} onEdit={openEdit} onDelete={(r) => api.deleteRoute(r.id)} />
      <Modal open={!!modal} onClose={() => setModal(null)} title={modal?.mode === "new" ? "Add route" : "Edit route"}>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3"><Field label="From"><Input value={form.from} onChange={(e) => setForm({ ...form, from: e.target.value })} /></Field><Field label="To"><Input value={form.to} onChange={(e) => setForm({ ...form, to: e.target.value })} /></Field></div>
          <div className="grid grid-cols-3 gap-3"><Field label="Distance (km)"><Input type="number" value={form.distanceKm} onChange={(e) => setForm({ ...form, distanceKm: e.target.value })} /></Field><Field label="Duration (min)"><Input type="number" value={form.durationMin} onChange={(e) => setForm({ ...form, durationMin: e.target.value })} /></Field><Field label="Base price ($)"><Input type="number" value={form.basePrice} onChange={(e) => setForm({ ...form, basePrice: e.target.value })} /></Field></div>
          <Button className="w-full" onClick={save} loading={busy}>Save route</Button>
        </div>
      </Modal>
    </Card>
  );
}

export function SchedulesTab() {
  const { api } = useApi();
  const routes = api.getRoutes(); const buses = api.getBuses();
  const [modal, setModal] = useState(null);
  const [form, setForm] = useState({ routeId: routes[0]?.id, busId: buses[0]?.id, departure: "", price: "" });
  const [busy, setBusy] = useState(false);
  const trips = routes.flatMap((r) => api.getTripsForRoute(r.id).map((t) => ({ ...t, routeLabel: `${r.from} → ${r.to}` }))).sort((a, b) => new Date(a.departure) - new Date(b.departure));
  const openNew = () => { setForm({ routeId: routes[0]?.id, busId: buses[0]?.id, departure: "", price: routes[0]?.basePrice || 25 }); setModal({ mode: "new" }); };
  const save = async () => {
    setBusy(true);
    const route = routes.find((r) => r.id === form.routeId);
    const dep = new Date(form.departure);
    const arr = new Date(dep.getTime() + route.durationMin * 60000);
    await api.addTrip({ routeId: form.routeId, busId: form.busId, departure: dep.toISOString(), arrival: arr.toISOString(), price: +form.price, seatsTotal: buses.find((b) => b.id === form.busId)?.capacity || 40 });
    setBusy(false); setModal(null);
  };
  return (
    <Card className="p-6">
      <div className="flex justify-between items-center mb-5"><h3 className="font-bold">Schedules</h3><Button size="sm" onClick={openNew}><Plus size={14} />Add trip</Button></div>
      <DataTable columns={[{ key: "route", label: "Route", render: (t) => t.routeLabel }, { key: "departure", label: "Departure", render: (t) => `${fmtDate(t.departure)} · ${fmtTime(t.departure)}` }, { key: "bus", label: "Bus", render: (t) => api.getBus(t.busId)?.plate }, { key: "price", label: "Price", render: (t) => money(t.price) }, { key: "status", label: "Status", render: (t) => <Badge tone={t.status === "scheduled" ? "success" : "neutral"}>{t.status}</Badge> }]} rows={trips} onDelete={(t) => api.deleteTrip(t.id)} />
      <Modal open={!!modal} onClose={() => setModal(null)} title="Add trip">
        <div className="space-y-4">
          <Field label="Route"><Select value={form.routeId} onChange={(e) => setForm({ ...form, routeId: e.target.value })}>{routes.map((r) => <option key={r.id} value={r.id}>{r.from} → {r.to}</option>)}</Select></Field>
          <Field label="Bus"><Select value={form.busId} onChange={(e) => setForm({ ...form, busId: e.target.value })}>{buses.map((b) => <option key={b.id} value={b.id}>{b.plate} — {b.model}</option>)}</Select></Field>
          <Field label="Departure"><Input type="datetime-local" value={form.departure} onChange={(e) => setForm({ ...form, departure: e.target.value })} /></Field>
          <Field label="Price ($)"><Input type="number" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} /></Field>
          <Button className="w-full" onClick={save} loading={busy}>Save trip</Button>
        </div>
      </Modal>
    </Card>
  );
}

export function PricingTab() {
  const { api } = useApi();
  const [edits, setEdits] = useState({});
  const routes = api.getRoutes();
  return (
    <Card className="p-6">
      <h3 className="font-bold mb-5">Base pricing per route</h3>
      <div className="space-y-3">
        {routes.map((r) => (
          <div key={r.id} className="flex items-center justify-between border-b border-[var(--line)] pb-3">
            <span className="font-semibold text-sm">{r.from} → {r.to}</span>
            <div className="flex items-center gap-2">
              <Input type="number" className="w-28" value={edits[r.id] ?? r.basePrice} onChange={(e) => setEdits({ ...edits, [r.id]: e.target.value })} />
              <Button size="sm" onClick={() => api.updateRoute(r.id, { basePrice: +(edits[r.id] ?? r.basePrice) })}>Save</Button>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}

export function AgentsTab() {
  const { api } = useApi();
  const agents = api.getAgents();
  const rows = agents.map((a) => { const bookings = api.getBookingsForAgent(a.id).filter((b) => b.status !== "cancelled"); return { ...a, salesCount: bookings.length, sales: bookings.reduce((s, b) => s + b.amount, 0) }; });

  const [modal, setModal] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", password: "", phone: "", commissionRate: 6 });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const create = async () => {
    setBusy(true); setErr("");
    try {
      await api.addAgent({ ...form, commissionRate: Number(form.commissionRate) / 100 });
      setModal(false);
      setForm({ name: "", email: "", password: "", phone: "", commissionRate: 6 });
    } catch (e) {
      setErr(e.message || "Could not create agent.");
    }
    setBusy(false);
  };

  return (
    <Card className="p-6">
      <div className="flex justify-between items-center mb-5">
        <h3 className="font-bold">Agents</h3>
        <Button size="sm" onClick={() => setModal(true)}><Plus size={14} />Add agent</Button>
      </div>
      <DataTable columns={[{ key: "name", label: "Name" }, { key: "email", label: "Email" }, { key: "phone", label: "Phone" }, { key: "salesCount", label: "Bookings" }, { key: "sales", label: "Sales", render: (a) => money(a.sales) }, { key: "commissionRate", label: "Rate", render: (a) => `${(a.commissionRate * 100).toFixed(0)}%` }]} rows={rows} />

      <Modal open={modal} onClose={() => setModal(false)} title="Add agent">
        <div className="space-y-4">
          <Field label="Full name"><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
          <Field label="Email"><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></Field>
          <Field label="Temporary password" hint="They can sign in with this immediately — share it securely."><Input type="text" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></Field>
          <Field label="Phone"><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="+252 6..." /></Field>
          <Field label="Commission rate (%)"><Input type="number" value={form.commissionRate} onChange={(e) => setForm({ ...form, commissionRate: e.target.value })} /></Field>
          {err && <p className="text-sm text-red-600 flex items-center gap-1.5"><AlertCircle size={13} />{err}</p>}
          <Button className="w-full" onClick={create} loading={busy} disabled={!form.name || !form.email || form.password.length < 6 || !form.phone}>Create agent</Button>
        </div>
      </Modal>
    </Card>
  );
}

export function ReportsTab() {
  const { api } = useApi();
  const bookings = api.getAllBookings();
  const download = () => {
    const rows = bookings.map((b) => { const t = api.getTrip(b.tripId), r = api.getRoute(t.routeId); return [b.ref, `${r.from}-${r.to}`, fmtDate(t.departure), b.seats.join(" "), b.amount, b.status].join(","); });
    const csv = ["ref,route,date,seats,amount,status", ...rows].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "duale-bookings-report.csv"; a.click();
  };
  return (
    <Card className="p-6">
      <div className="flex justify-between items-center mb-5"><h3 className="font-bold">Bookings report</h3><Button size="sm" onClick={download}><Download size={14} />Export CSV</Button></div>
      <DataTable columns={[{ key: "ref", label: "Ref" }, { key: "route", label: "Route", render: (b) => { const t = api.getTrip(b.tripId), r = api.getRoute(t.routeId); return `${r.from} → ${r.to}`; } }, { key: "date", label: "Date", render: (b) => fmtDate(api.getTrip(b.tripId).departure) }, { key: "amount", label: "Amount", render: (b) => money(b.amount) }, { key: "status", label: "Status" }]} rows={bookings} />
    </Card>
  );
}

export function RevenueTab() {
  const { api } = useApi();
  const bookings = api.getAllBookings().filter((b) => b.status !== "cancelled");
  const byRoute = useMemo(() => { const map = {}; bookings.forEach((b) => { const t = api.getTrip(b.tripId), r = api.getRoute(t.routeId); const key = `${r.from}→${r.to}`; map[key] = (map[key] || 0) + b.amount; }); return Object.entries(map).map(([name, value]) => ({ name, value })); }, [bookings]);
  const COLORS = ["#0d3b28", "#12603f", "#1a7a4c", "#22a35e", "#5bd68a"];
  const total = bookings.reduce((s, b) => s + b.amount, 0);
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card className="p-6">
        <h3 className="font-bold mb-4">Revenue by route</h3>
        {byRoute.length === 0 ? <EmptyState title="No revenue yet" /> : (
          <ResponsiveContainer width="100%" height={280}>
            <PieChart>
              <Pie data={byRoute} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={95} label={(e) => `${money(e.value)}`}>
                {byRoute.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Legend /><Tooltip formatter={(v) => money(v)} />
            </PieChart>
          </ResponsiveContainer>
        )}
      </Card>
      <div className="space-y-4">
        <StatCard icon={DollarSign} label="Total revenue" value={money(total)} />
        <StatCard icon={Ticket} label="Avg. booking value" value={bookings.length ? money(total / bookings.length) : "$0.00"} />
        <StatCard icon={TrendingUp} label="Confirmed bookings" value={bookings.length} />
      </div>
    </div>
  );
}

export function SettingsTab() {
  const [form, setForm] = useState({ companyName: "Du'ale", phone: "+252 61 1234567", email: "support@duale.so", currency: "USD" });
  const [saved, setSaved] = useState(false);
  return (
    <Card className="p-6 max-w-md">
      <h3 className="font-bold mb-5">Company settings</h3>
      <div className="space-y-4">
        <Field label="Company name"><Input value={form.companyName} onChange={(e) => setForm({ ...form, companyName: e.target.value })} /></Field>
        <Field label="Support phone"><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></Field>
        <Field label="Support email"><Input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></Field>
        <Field label="Currency"><Select value={form.currency} onChange={(e) => setForm({ ...form, currency: e.target.value })}><option>USD</option><option>SOS</option></Select></Field>
        <Button onClick={() => { setSaved(true); setTimeout(() => setSaved(false), 2000); }}>Save settings</Button>
        {saved && <p className="text-sm text-[var(--green-700)] flex items-center gap-1.5"><CheckCircle2 size={14} />Saved locally — wire this to a `settings` table if you want it persisted.</p>}
      </div>
    </Card>
  );
}

export function UsersTab() {
  const { api } = useApi();
  const users = api.getUsers();
  return (
    <Card className="p-6">
      <h3 className="font-bold mb-5">All users</h3>
      <DataTable columns={[{ key: "name", label: "Name" }, { key: "email", label: "Email" }, { key: "role", label: "Role", render: (u) => <Select value={u.role} onChange={(e) => api.updateUserRole(u.id, { role: e.target.value })} className="!py-1.5 !text-sm w-32"><option value="customer">Customer</option><option value="agent">Agent</option><option value="manager">Manager</option></Select> }, { key: "phone", label: "Phone" }]} rows={users} />
    </Card>
  );
}
