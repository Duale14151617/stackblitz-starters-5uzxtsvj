import React, { useState } from "react";
import { apiConfigured } from "./lib/apiClient";
import { AuthProvider, useAuth } from "./context/AuthContext";
import { DataProvider, useApi } from "./context/DataContext";
import { LoadingScreen, NotConfiguredScreen } from "./components/StatusScreens";
import PublicNav from "./components/PublicNav";
import Footer from "./components/Footer";
import AuthModal from "./components/AuthModal";
import HomePage from "./pages/HomePage";
import ResultsPage from "./pages/ResultsPage";
import BookingFlow from "./pages/BookingFlow";
import CustomerDashboard from "./pages/CustomerDashboard";
import AgentDashboard from "./pages/AgentDashboard";
import ManagerDashboard from "./pages/ManagerDashboard";
import { addDays } from "./lib/helpers";
import { Button } from "./components/ui";

function AppShell() {
  const { user, loading } = useAuth();
  const { refLoaded, error } = useApi();
  const [view, setView] = useState("home"); // home | results | booking | dashboard
  const [query, setQuery] = useState(null);
  const [selectedTrip, setSelectedTrip] = useState(null);
  const [agentWalkIn, setAgentWalkIn] = useState(false);
  const [authOpen, setAuthOpen] = useState(false);

  if (loading || !refLoaded) return <LoadingScreen />;

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[var(--cream)] p-6">
        <div className="bg-white border border-[var(--line)] rounded-2xl p-8 max-w-md text-center">
          <p className="font-bold text-red-600 mb-2">Couldn&apos;t load data from the server</p>
          <p className="text-sm text-[var(--gray-600)]">{error}</p>
        </div>
      </div>
    );
  }

  const handleSearch = (q) => { setQuery(q); setView("results"); };
  const handleSelectTrip = (t) => { setSelectedTrip(t); setAgentWalkIn(false); setView("booking"); };
  const startWalkIn = () => {
    setAgentWalkIn(true);
    setQuery({ from: "Mogadishu", to: "Hargeisa", date: addDays(new Date(), 1).toISOString().slice(0, 10), passengers: 1 });
    setView("results");
  };
  const nav = (target) => {
    if (target === "dashboard" && !user) return setAuthOpen(true);
    if (target === "book") return setView("home");
    setView(target === "routes" ? "home" : target);
  };

  return (
    <div className="min-h-screen flex flex-col">
      {view !== "dashboard" && <PublicNav onNav={nav} onOpenAuth={() => setAuthOpen(true)} />}
      <AuthModal open={authOpen} onClose={() => setAuthOpen(false)} />

      <div className="flex-1">
        {view === "home" && <HomePage onSearch={handleSearch} />}
        {view === "results" && query && <ResultsPage query={query} onSelectTrip={handleSelectTrip} onBack={() => setView("home")} />}
        {view === "booking" && selectedTrip && (
          agentWalkIn && (!user || user.role !== "agent") ? (
            <div className="max-w-md mx-auto px-6 py-16 text-center">
              <p className="text-[var(--gray-600)] mb-4">Sign in as an agent to create a walk-in booking.</p>
              <Button onClick={() => setAuthOpen(true)}>Sign in</Button>
            </div>
          ) : (
            <BookingFlow
              trip={selectedTrip}
              passengerCount={query?.passengers || 1}
              actingAsAgent={agentWalkIn}
              onDone={() => setView("dashboard")}
              onCancel={() => setView("results")}
            />
          )
        )}
        {view === "dashboard" && user && (
          user.role === "customer" ? <CustomerDashboard goBook={() => setView("home")} /> :
          user.role === "agent" ? <AgentDashboard startWalkInBooking={startWalkIn} /> :
          <ManagerDashboard />
        )}
      </div>

      {view !== "dashboard" && <Footer />}
    </div>
  );
}

export default function App() {
  if (!apiConfigured) return <NotConfiguredScreen />;
  return (
    <AuthProvider>
      <DataProvider>
        <AppShell />
      </DataProvider>
    </AuthProvider>
  );
}
