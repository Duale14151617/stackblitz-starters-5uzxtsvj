import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import { request, getToken, setToken } from "../lib/apiClient";

const AuthCtx = createContext(null);
export const useAuth = () => useContext(AuthCtx);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = getToken();
    if (!token) { setLoading(false); return; }
    request("/auth/me.php")
      .then(({ user }) => setUser(user))
      .catch(() => setToken(null)) // expired/invalid token — just sign out quietly
      .finally(() => setLoading(false));
  }, []);

  const signIn = useCallback(async (email, password) => {
    const { token, user } = await request("/auth/login.php", { method: "POST", body: { email, password }, auth: false });
    setToken(token);
    setUser(user);
    return user;
  }, []);

  const signUp = useCallback(async (name, email, password, phone) => {
    const { token, user } = await request("/auth/signup.php", { method: "POST", body: { name, email, password, phone }, auth: false });
    setToken(token);
    setUser(user);
    return { user };
  }, []);

  const signOut = useCallback(() => {
    setToken(null);
    setUser(null);
  }, []);

  return (
    <AuthCtx.Provider value={{ user, loading, signIn, signUp, signOut }}>
      {children}
    </AuthCtx.Provider>
  );
}
