import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import { buildApi, fetchReferenceData, fetchUserScopedData } from "../lib/api";
import { useAuth } from "./AuthContext";

const ApiCtx = createContext(null);
export const useApi = () => useContext(ApiCtx);

const empty = { routes: [], buses: [], trips: [], bookings: [], notifications: [], users: [] };

export function DataProvider({ children }) {
  const { user } = useAuth();
  const [db, setDb] = useState(empty);
  const [refLoaded, setRefLoaded] = useState(false);
  const [error, setError] = useState(null);

  // Public reference data (routes/buses/trips) — fetched once from the
  // unauthenticated /reference.php endpoint, so this works even signed out.
  useEffect(() => {
    fetchReferenceData()
      .then((ref) => setDb((prev) => ({ ...prev, ...ref })))
      .catch((e) => setError(e.message))
      .finally(() => setRefLoaded(true));
  }, []);

  // User-scoped data (bookings/notifications, plus all profiles for managers)
  // — refetched whenever who's signed in changes.
  useEffect(() => {
    if (!user) { setDb((prev) => ({ ...prev, bookings: [], notifications: [] })); return; }
    fetchUserScopedData(user)
      .then((extra) => setDb((prev) => ({
        ...prev,
        bookings: extra.bookings,
        notifications: extra.notifications,
        users: mergeUsers(prev.users, extra.users),
      })))
      .catch((e) => setError(e.message));
  }, [user]);

  const api = useMemo(() => buildApi(db, setDb), [db]);

  return <ApiCtx.Provider value={{ api, refLoaded, error }}>{children}</ApiCtx.Provider>;
}

function mergeUsers(existing, incoming) {
  const map = new Map(existing.map((u) => [u.id, u]));
  incoming.forEach((u) => map.set(u.id, u));
  return [...map.values()];
}
